# サーバーを開始する。
Write-Host "Online game server start."
$listener = New-Object system.net.HttpListener
$listener.Prefixes.Add('http://127.0.0.1:8080/')
$listener.Start()

$data="" #変数を初期化する。

while($true)
{
	# クライアントからコマンドとパラメーターを受け取る。
	$context = $listener.GetContext()
	$request = $context.Request
	$input = $request.RawUrl.Replace("/index.htm?", "")

	# コマンドに対する応答を作る。
	$array = $input.Split("&")
	$command = $array[0].Replace("command=", "")
	$parameter = $array[1].Replace("parameter=", "")
	if($command.Equals("set")){                      # [コマンドset]。
		$data = $parameter                           #  パラメーターを保持する。
		$output = "OK"                               #  OKを応答とする。
	}elseif($command.Equals("get")){                 # [コマンドget]
		$output = $data                              #  保持しているパラメーターを応答とする。
	}

	# クライアントへ応答を返す。
	$buffer = [System.Text.Encoding]::UTF8.GetBytes($output)
 	$response = $context.Response
	$response.ContentLength64 = $buffer.Length
	$output = $response.OutputStream
	$output.Write($buffer,0,$buffer.Length)
	$output.Close()
}
