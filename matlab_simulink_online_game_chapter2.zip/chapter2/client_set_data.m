% コマンドsetでサーバーに要求を出す。
req = matlab.net.http.RequestMessage;
uri = matlab.net.URI('http://localhost:8080/index.htm?command=set&parameter=ABC'); % パラメーターはABC
rsp = send(req,uri);
dat = transpose(rsp.Body.Data); % サーバーから受け取った応答
native2unicode(dat) % 応答を文字配列に変換
