function ret=chapter10_fight_home_licence_show_screen(data)
    pic_size=50;
    sz=size(data);
    fig=evalin('base','fig');
    figure(fig);
    pic=evalin('base','pic');
    gamestart=evalin('base','gamestart');
    gameover=evalin('base','gameover');
    gameclear=evalin('base','gameclear');
    client_right=evalin('base','client_right');
    client_left=evalin('base','client_left');
    money=evalin('base','money');
    right=evalin('base','right');
    left=evalin('base','left');
    right_up=evalin('base','right_up');
    left_up=evalin('base','left_up');
    pic100=evalin('base','pic100');
    pic200=evalin('base','pic200');
    pic500=evalin('base','pic500');
    pic1000=evalin('base','pic1000');
    for i=1:sz(1)
        c=data(i,1);
        x=data(i,2);
        y=data(i,3);
        switch c
            case 1
                pic=chapter10_fight_home_licence_show_screen_chr(pic,gamestart,x,y);
            case 2
                pic=chapter10_fight_home_licence_show_screen_chr(pic,gameover,x,y);
            case 3
                pic=chapter10_fight_home_licence_show_screen_chr(pic,gameclear,x,y);
            case 11
                pic=chapter10_fight_home_licence_show_screen_chr(pic,client_right,x,y);
            case 12
                pic=chapter10_fight_home_licence_show_screen_chr(pic,money,x,y);
            case 21
                pic=chapter10_fight_home_licence_show_screen_chr(pic,pic100,x,y);
            case 22
                pic=chapter10_fight_home_licence_show_screen_chr(pic,pic200,x,y);
            case 23
                pic=chapter10_fight_home_licence_show_screen_chr(pic,pic500,x,y);
            case 24
                pic=chapter10_fight_home_licence_show_screen_chr(pic,pic1000,x,y);
            case 31
                pic=chapter10_fight_home_licence_show_screen_chr(pic,right,x,y);
            case 32
                pic=chapter10_fight_home_licence_show_screen_chr(pic,left,x,y);
            case 33
                pic=chapter10_fight_home_licence_show_screen_chr(pic,right_up,x,y);
            case 34
                pic=chapter10_fight_home_licence_show_screen_chr(pic,left_up,x,y);
        end
    end        
    imshow(pic,'Border','tight','InitialMagnification','fit');
    ret=0;
end

function pic=chapter10_fight_home_licence_show_screen_chr(pic_tmp,chr,x,y)
    mask=chr==0;
    mask(:,:,1)=mask(:,:,1) & mask(:,:,2) & mask(:,:,3);
    mask(:,:,2)=mask(:,:,1);
    mask(:,:,3)=mask(:,:,1);
    mask=cast(mask,'uint8');
    sz=size(chr);
    h=sz(1);
    w=sz(2);
    pic=pic_tmp;
    pic(1+y:h+y,1+x:w+x,1:3)=pic(1+y:h+y,1+x:w+x,1:3) .* mask;
    pic(1+y:h+y,1+x:w+x,1:3)=pic(1+y:h+y,1+x:w+x,1:3) + chr;
end
