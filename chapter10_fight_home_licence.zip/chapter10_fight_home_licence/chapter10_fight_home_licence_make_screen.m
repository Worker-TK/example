function chapter10_fight_home_licence_make_screen
    pic_size=50;
    fig = figure;
    fig.Name = 'Fight Home Licence';
    fig.NumberTitle = 'off';
    fig.MenuBar = 'none';
    fig.ToolBar = 'none';
    fig.WindowState = 'fullscreen';
    assignin('base','fig',fig);
    gamestart=imread('.\pic\gamestart.png','png');
    assignin('base','gamestart',gamestart);
    gameover=imread('.\pic\gameover.png','png');
    assignin('base','gameover',gameover);
    gameclear=imread('.\pic\gameclear.png','png');
    assignin('base','gameclear',gameclear);
    client_right=imread('.\pic\client_right.png','png');
    assignin('base','client_right',client_right);
    client_left=imread('.\pic\client_left.png','png');
    assignin('base','client_left',client_left);
    money=imread('.\pic\money.png','png');
    assignin('base','money',money);
    right=imread('.\pic\right.png','png');
    assignin('base','right',right);
    left=imread('.\pic\left.png','png');
    assignin('base','left',left);
    right_up=imread('.\pic\right_up.png','png');
    assignin('base','right_up',right_up);
    left_up=imread('.\pic\left_up.png','png');
    assignin('base','left_up',left_up);
    pic100=imread('.\pic\100.png','png');
    assignin('base','pic100',pic100);
    pic200=imread('.\pic\200.png','png');
    assignin('base','pic200',pic200);
    pic500=imread('.\pic\500.png','png');
    assignin('base','pic500',pic500);
    pic1000=imread('.\pic\1000.png','png');
    assignin('base','pic1000',pic1000);
    data=[0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0; ...
          0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0; ...
          0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0; ...
          0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0; ...
          1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 2 3 0 0; ...
          0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0; ...
          0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0; ...
          0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0; ...
          0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0; ...
          2 3 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 0 0; ...
          2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0; ...
          2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0; ...
          2 3 0 0 0 0 0 0 0 2 3 0 0 0 0 2 3 0 0 0 0 2 3 0 0 0 0 0 0 0 0 0 0 0; ...
          2 3 0 0 0 0 0 0 0 2 3 0 0 0 0 2 3 0 0 0 0 2 3 0 0 0 0 0 0 0 0 0 0 0; ...
          1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 2 3 0 0; ...
          0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0; ...
          0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0; ...
          0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0; ...
          1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 2 3 0 0; ...
          1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1];
    [pic map]=chapter10_fight_home_licence_make_screen_pic(data);
    assignin('base','pic',pic);
    set_param('chapter10_fight_home_licence/Subsystem/Control/map','Value', mat2str(map));
    set_param('chapter10_fight_home_licence/Subsystem/Control/key','Value', num2str(0));
    fig.KeyPressFcn = @key_press_callback;
    fig.KeyReleaseFcn = @key_release_callback;
    function key_press_callback(src,data)
        key=6;
        if strcmp(data.Key,'uparrow')
            key=1;
        elseif strcmp(data.Key,'rightarrow')
            key=2;
        elseif strcmp(data.Key,'downarrow')
            key=3;
        elseif strcmp(data.Key,'leftarrow')
            key=4;
        elseif strcmp(data.Key,'return')
            key=5;
        elseif strcmp(data.Key,'space')
            key=6;
        end
        set_param('chapter10_fight_home_licence/Subsystem/Control/key','Value', num2str(key));
    end
    function key_release_callback(src,data)
        if strcmp(data.Key,'uparrow')
            set_param('chapter10_fight_home_licence/Subsystem/Control/key','Value', num2str(0));
        elseif strcmp(data.Key,'rightarrow')
            set_param('chapter10_fight_home_licence/Subsystem/Control/key','Value', num2str(0));
        elseif strcmp(data.Key,'downarrow')
            set_param('chapter10_fight_home_licence/Subsystem/Control/key','Value', num2str(0));
        elseif strcmp(data.Key,'leftarrow')
            set_param('chapter10_fight_home_licence/Subsystem/Control/key','Value', num2str(0));
        end
    end
end

function [pic map]=chapter10_fight_home_licence_make_screen_pic(data)
    pic_size=50;
    map_size=2;
    sz=size(data);
    black=imread('.\pic\black.png','png');
    block=imread('.\pic\block.png','png');
    ladder_left=imread('.\pic\ladder_left.png','png');
    ladder_right=imread('.\pic\ladder_right.png','png');
    all=zeros(pic_size*sz(1),pic_size*sz(2),3);
    all=cast(all,'uint8');
    map=zeros(map_size*sz(1),map_size*sz(2));
    map=cast(map,'uint8');
    tmp1=ones(map_size,map_size);
    tmp1=cast(tmp1,'uint8');
    tmp2=ones(map_size,map_size) * 2;
    tmp2=cast(tmp2,'uint8');
    for i=1:sz(1)
        for j=1:sz(2)
            switch data(i,j)
                case 0
                    all(1+pic_size*(i-1):pic_size+pic_size*(i-1),1+pic_size*(j-1):pic_size+pic_size*(j-1),1:3)=black(1:pic_size,1:pic_size,1:3);
                case 1
                    all(1+pic_size*(i-1):pic_size+pic_size*(i-1),1+pic_size*(j-1):pic_size+pic_size*(j-1),1:3)=block(1:pic_size,1:pic_size,1:3);
                    map(1+map_size*(i-1):map_size+map_size*(i-1),1+map_size*(j-1):map_size+map_size*(j-1))=tmp2(1:map_size,1:map_size);
                case 2
                    all(1+pic_size*(i-1):pic_size+pic_size*(i-1),1+pic_size*(j-1):pic_size+pic_size*(j-1),1:3)=ladder_left(1:pic_size,1:pic_size,1:3);
                    map(1+map_size*(i-1):map_size+map_size*(i-1),1+map_size*(j-1):map_size+map_size*(j-1))=tmp1(1:map_size,1:map_size);
                case 3
                    all(1+pic_size*(i-1):pic_size+pic_size*(i-1),1+pic_size*(j-1):pic_size+pic_size*(j-1),1:3)=ladder_right(1:pic_size,1:pic_size,1:3);
                    map(1+map_size*(i-1):map_size+map_size*(i-1),1+map_size*(j-1):map_size+map_size*(j-1))=tmp1(1:map_size,1:map_size);
                otherwise
                    all(1+pic_size*(i-1):pic_size+pic_size*(i-1),1+pic_size*(j-1):pic_size+pic_size*(j-1),1:3)=black(1:pic_size,1:pic_size,1:3);
            end
        end
    end
    pic=all;
end
