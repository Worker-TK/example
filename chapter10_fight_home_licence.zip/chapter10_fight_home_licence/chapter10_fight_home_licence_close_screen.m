function chapter10_fight_home_licence_close_screen
    fig=evalin('base','fig');
    close(fig);
end
