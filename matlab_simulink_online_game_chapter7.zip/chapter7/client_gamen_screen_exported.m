classdef client_gamen_screen_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure         matlab.ui.Figure
        Button           matlab.ui.control.Button
        Button_2         matlab.ui.control.Button
        Image1           matlab.ui.control.Image
        Image2           matlab.ui.control.Image
        Image3           matlab.ui.control.Image
        Image4           matlab.ui.control.Image
        Image5           matlab.ui.control.Image
        Image6           matlab.ui.control.Image
        Image7           matlab.ui.control.Image
        Image8           matlab.ui.control.Image
        Image9           matlab.ui.control.Image
        Image10          matlab.ui.control.Image
        Label_matching   matlab.ui.control.Label
        Label_cycle      matlab.ui.control.Label
        Label_judge      matlab.ui.control.Label
        Label_marubatsu  matlab.ui.control.Label
    end

    properties (Access = private)
        update_timer
    end
    
    properties (Access = public)
        judge_old
        screen_old
    end
    
    methods (Access = private)
        
        function gametimer_fun(app, src, event)
            matching=evalin('base','matching');
            marubatsu=evalin('base','marubatsu');
            cycle=evalin('base','cycle');
            screen=evalin('base','screen');
            judge=evalin('base','judge');
            
            if matching==0
                app.Label_matching.Text = 'マッチング：なし';
            elseif matching==1
                app.Label_matching.Text = 'マッチング：待機';
                app.Button.Enable=0;
            elseif matching==2
                app.Label_matching.Text = 'マッチング：完了';
                app.Button.Enable=0;
                
                if marubatsu==1
                    app.Label_marubatsu.Text = '先攻／後攻：先攻（○）';
                elseif marubatsu==2
                    app.Label_marubatsu.Text = '先攻／後攻：後攻（×）';
                end
                
                if cycle==0
                    app.Label_cycle.Text = '順番：相手の番です。';
                elseif cycle==1
                    app.Label_cycle.Text = '順番：あなたの番です。';
                end
                
                if judge==0
                    app.Label_judge.Text = '勝敗：勝負中です。';
                elseif judge==1
                    app.Label_judge.Text = '勝敗：あなたの勝ちです。';
                    stop(app.update_timer);
                elseif judge==2
                    app.Label_judge.Text = '勝敗：あなたの負けです。';
                    stop(app.update_timer);
                end
                if judge~=app.judge_old
                    if judge==0
                        app.Image10.ImageSource = 'pistol_pose_man.png';
                    elseif judge==1
                        app.Image10.ImageSource = 'pose_win_boy.png';
                    elseif judge==2
                        app.Image10.ImageSource = 'pose_lose_boy.png';
                    end
                end
                
                if screen(1,1)~=app.screen_old(1,1)
                    if screen(1,1)==0
                        app.Image1.ImageSource = 'mark_blank.png';
                    elseif screen(1,1)==1
                        app.Image1.ImageSource = 'mark_maru.png';                        
                    elseif screen(1,1)==2
                        app.Image1.ImageSource = 'mark_batsu.png';                        
                    end
                end
                
                if screen(2,1)~=app.screen_old(2,1)
                    if screen(2,1)==0
                        app.Image2.ImageSource = 'mark_blank.png';
                    elseif screen(2,1)==1
                        app.Image2.ImageSource = 'mark_maru.png';                        
                    elseif screen(2,1)==2
                        app.Image2.ImageSource = 'mark_batsu.png';                        
                    end
                end

                if screen(3,1)~=app.screen_old(3,1)
                    if screen(3,1)==0
                        app.Image3.ImageSource = 'mark_blank.png';
                    elseif screen(3,1)==1
                        app.Image3.ImageSource = 'mark_maru.png';                        
                    elseif screen(3,1)==2
                        app.Image3.ImageSource = 'mark_batsu.png';                        
                    end
                end

                if screen(1,2)~=app.screen_old(1,2)
                    if screen(1,2)==0
                        app.Image4.ImageSource = 'mark_blank.png';
                    elseif screen(1,2)==1
                        app.Image4.ImageSource = 'mark_maru.png';                        
                    elseif screen(1,2)==2
                        app.Image4.ImageSource = 'mark_batsu.png';                        
                    end
                end

                if screen(2,2)~=app.screen_old(2,2)
                    if screen(2,2)==0
                        app.Image5.ImageSource = 'mark_blank.png';
                    elseif screen(2,2)==1
                        app.Image5.ImageSource = 'mark_maru.png';                        
                    elseif screen(2,2)==2
                        app.Image5.ImageSource = 'mark_batsu.png';                        
                    end
                end

                if screen(3,2)~=app.screen_old(3,2)
                    if screen(3,2)==0
                        app.Image6.ImageSource = 'mark_blank.png';
                    elseif screen(3,2)==1
                        app.Image6.ImageSource = 'mark_maru.png';                        
                    elseif screen(3,2)==2
                        app.Image6.ImageSource = 'mark_batsu.png';                        
                    end
                end
                
                if screen(1,3)~=app.screen_old(1,3)
                    if screen(1,3)==0
                        app.Image7.ImageSource = 'mark_blank.png';
                    elseif screen(1,3)==1
                        app.Image7.ImageSource = 'mark_maru.png';                        
                    elseif screen(1,3)==2
                        app.Image7.ImageSource = 'mark_batsu.png';                        
                    end
                end
                
                if screen(2,3)~=app.screen_old(2,3)
                    if screen(2,3)==0
                        app.Image8.ImageSource = 'mark_blank.png';
                    elseif screen(2,3)==1
                        app.Image8.ImageSource = 'mark_maru.png';                        
                    elseif screen(2,3)==2
                        app.Image8.ImageSource = 'mark_batsu.png';                        
                    end
                end
                
                if screen(3,3)~=app.screen_old(3,3)
                    if screen(3,3)==0
                        app.Image9.ImageSource = 'mark_blank.png';
                    elseif screen(3,3)==1
                        app.Image9.ImageSource = 'mark_maru.png';                        
                    elseif screen(3,3)==2
                        app.Image9.ImageSource = 'mark_batsu.png';                        
                    end
                end
                
                app.judge_old = judge;
                app.screen_old = screen;
            end
        end
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            app.judge_old = 0;
            app.screen_old = zeros(3,3);
            app.update_timer = timer('Period',1,'ExecutionMode','fixedSpacing','TasksToExecute', Inf,'TimerFcn', @app.gametimer_fun);
            start(app.update_timer);
        end

        % Button pushed function: Button_2
        function Button_2Pushed(app, event)
            set_param('matlab_simulink_online_game/ゲーム終了処理/ゲーム終了ボタン操作','Value', '1');
            stop(app.update_timer);
            delete(app.update_timer);
            delete(app);
        end

        % Button pushed function: Button
        function ButtonPushed(app, event)
            set_param('matlab_simulink_online_game/ゲーム制御処理/マッチング完了時のみ実行する処理/操作できる時の処理/ユーザー操作','Value', '0');
            set_param('matlab_simulink_online_game/マッチング処理/マッチングなし時の処理/マッチング実行ボタン操作','Value', '1');
        end

        % Image clicked function: Image1
        function Image1Clicked(app, event)
            set_param('matlab_simulink_online_game/ゲーム制御処理/マッチング完了時のみ実行する処理/操作できる時の処理/ユーザー操作','Value', '2');
        end

        % Image clicked function: Image2
        function Image2Clicked(app, event)
            set_param('matlab_simulink_online_game/ゲーム制御処理/マッチング完了時のみ実行する処理/操作できる時の処理/ユーザー操作','Value', '3');
        end

        % Image clicked function: Image3
        function Image3Clicked(app, event)
            set_param('matlab_simulink_online_game/ゲーム制御処理/マッチング完了時のみ実行する処理/操作できる時の処理/ユーザー操作','Value', '4');
        end

        % Image clicked function: Image4
        function Image4Clicked(app, event)
            set_param('matlab_simulink_online_game/ゲーム制御処理/マッチング完了時のみ実行する処理/操作できる時の処理/ユーザー操作','Value', '5');
        end

        % Image clicked function: Image5
        function Image5Clicked(app, event)
            set_param('matlab_simulink_online_game/ゲーム制御処理/マッチング完了時のみ実行する処理/操作できる時の処理/ユーザー操作','Value', '6');
        end

        % Image clicked function: Image6
        function Image6Clicked(app, event)
            set_param('matlab_simulink_online_game/ゲーム制御処理/マッチング完了時のみ実行する処理/操作できる時の処理/ユーザー操作','Value', '7');
        end

        % Image clicked function: Image7
        function Image7Clicked(app, event)
            set_param('matlab_simulink_online_game/ゲーム制御処理/マッチング完了時のみ実行する処理/操作できる時の処理/ユーザー操作','Value', '8');
        end

        % Image clicked function: Image8
        function Image8Clicked(app, event)
            set_param('matlab_simulink_online_game/ゲーム制御処理/マッチング完了時のみ実行する処理/操作できる時の処理/ユーザー操作','Value', '9');
        end

        % Image clicked function: Image9
        function Image9Clicked(app, event)
            set_param('matlab_simulink_online_game/ゲーム制御処理/マッチング完了時のみ実行する処理/操作できる時の処理/ユーザー操作','Value', '10');
        end

        % Close request function: UIFigure
        function UIFigureCloseRequest(app, event)
            stop(app.update_timer);
            delete(app.update_timer);
            delete(app)
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 341 502];
            app.UIFigure.Name = 'MATLAB App';
            app.UIFigure.CloseRequestFcn = createCallbackFcn(app, @UIFigureCloseRequest, true);

            % Create Button
            app.Button = uibutton(app.UIFigure, 'push');
            app.Button.ButtonPushedFcn = createCallbackFcn(app, @ButtonPushed, true);
            app.Button.Position = [11 466 100 27];
            app.Button.Text = 'マッチング実行';

            % Create Button_2
            app.Button_2 = uibutton(app.UIFigure, 'push');
            app.Button_2.ButtonPushedFcn = createCallbackFcn(app, @Button_2Pushed, true);
            app.Button_2.Position = [231 466 100 27];
            app.Button_2.Text = 'ゲーム終了';

            % Create Image1
            app.Image1 = uiimage(app.UIFigure);
            app.Image1.ImageClickedFcn = createCallbackFcn(app, @Image1Clicked, true);
            app.Image1.Position = [11 233 100 100];
            app.Image1.ImageSource = 'mark_blank.png';

            % Create Image2
            app.Image2 = uiimage(app.UIFigure);
            app.Image2.ImageClickedFcn = createCallbackFcn(app, @Image2Clicked, true);
            app.Image2.Position = [11 123 100 100];
            app.Image2.ImageSource = 'mark_blank.png';

            % Create Image3
            app.Image3 = uiimage(app.UIFigure);
            app.Image3.ImageClickedFcn = createCallbackFcn(app, @Image3Clicked, true);
            app.Image3.Position = [11 13 100 100];
            app.Image3.ImageSource = 'mark_blank.png';

            % Create Image4
            app.Image4 = uiimage(app.UIFigure);
            app.Image4.ImageClickedFcn = createCallbackFcn(app, @Image4Clicked, true);
            app.Image4.Position = [121 233 100 100];
            app.Image4.ImageSource = 'mark_blank.png';

            % Create Image5
            app.Image5 = uiimage(app.UIFigure);
            app.Image5.ImageClickedFcn = createCallbackFcn(app, @Image5Clicked, true);
            app.Image5.Position = [121 123 100 100];
            app.Image5.ImageSource = 'mark_blank.png';

            % Create Image6
            app.Image6 = uiimage(app.UIFigure);
            app.Image6.ImageClickedFcn = createCallbackFcn(app, @Image6Clicked, true);
            app.Image6.Position = [121 13 100 100];
            app.Image6.ImageSource = 'mark_blank.png';

            % Create Image7
            app.Image7 = uiimage(app.UIFigure);
            app.Image7.ImageClickedFcn = createCallbackFcn(app, @Image7Clicked, true);
            app.Image7.Position = [231 233 100 100];
            app.Image7.ImageSource = 'mark_blank.png';

            % Create Image8
            app.Image8 = uiimage(app.UIFigure);
            app.Image8.ImageClickedFcn = createCallbackFcn(app, @Image8Clicked, true);
            app.Image8.Position = [231 123 100 100];
            app.Image8.ImageSource = 'mark_blank.png';

            % Create Image9
            app.Image9 = uiimage(app.UIFigure);
            app.Image9.ImageClickedFcn = createCallbackFcn(app, @Image9Clicked, true);
            app.Image9.Position = [231 13 100 100];
            app.Image9.ImageSource = 'mark_blank.png';

            % Create Image10
            app.Image10 = uiimage(app.UIFigure);
            app.Image10.Position = [231 353 100 100];
            app.Image10.ImageSource = 'pistol_pose_man.png';

            % Create Label_matching
            app.Label_matching = uilabel(app.UIFigure);
            app.Label_matching.Position = [11 431 210 22];
            app.Label_matching.Text = 'マッチング：なし';

            % Create Label_cycle
            app.Label_cycle = uilabel(app.UIFigure);
            app.Label_cycle.Position = [11 371 210 22];
            app.Label_cycle.Text = '順番：';

            % Create Label_judge
            app.Label_judge = uilabel(app.UIFigure);
            app.Label_judge.Position = [11 341 210 22];
            app.Label_judge.Text = '勝敗：';

            % Create Label_marubatsu
            app.Label_marubatsu = uilabel(app.UIFigure);
            app.Label_marubatsu.Position = [11 401 210 22];
            app.Label_marubatsu.Text = '先攻／後攻：';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = client_gamen_screen_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end