function client_mobile
    % localhostにはサーバーのパブリックIPを設定
    serverip = 'localhost:8080';

    % ゲーム開始を表示
    disp('ゲーム開始');
        
    % サーバーにマッチング要求する。
    req = matlab.net.http.RequestMessage;
    uri = matlab.net.URI(['http://' serverip '/index.htm?command=MatchingReq&parameter=']);
    try
        rsp = send(req,uri); % サーバーに送信して応答を受け取る。
        dat = transpose(rsp.Body.Data); % 行と列を転置する。
        str=native2unicode(dat);
    catch e
        str='TIMEOUT';
    end
    disp(['マッチング状況：' str]);
    marubatsu = 2; % 後攻

    % マッチング状況がWAIT(マッチング待ち)の場合、
    while strcmp(str,'WAIT')        
        marubatsu = 1; % 先攻
        pause(2);
        % サーバーからマッチング状況を取得する。
        req = matlab.net.http.RequestMessage;
        uri = matlab.net.URI(['http://' serverip '/index.htm?command=MatchingGet&parameter=']);
        try
            rsp = send(req,uri); % サーバーに送信して応答を受け取る。
            dat = transpose(rsp.Body.Data); % 行と列を転置する。
            str=native2unicode(dat);
        catch e
            str='TIMEOUT';        
        end
        disp(['マッチング状況：' str]);
    end

    % マッチング状況がCOMPLETE(マッチング完了)の場合、
    screen = [0 0 0 0 0 0 0 0 0 0];
    screen_before = [-1 -1 -1 -1 -1 -1 -1 -1 -1 -1];
    while strcmp(str,'COMPLETE')
        % 盤面データをサーバーから取得する。
        req = matlab.net.http.RequestMessage;
        uri = matlab.net.URI(['http://' serverip '/index.htm?command=ScreenGet&parameter=']);
        try
            rsp = send(req,uri); % サーバーに送信して応答を受け取る。
            dat = transpose(rsp.Body.Data); % 行と列を転置する。
            tmp = native2unicode([double(dat) zeros(1,19-size(dat,2))]); % 19固定の文字に変換する。
            tmp = replace(tmp,'_',' '); % アンダーバーをスペースに置換する。
            screen = str2num(tmp);
            if sum(screen==screen_before)<10
                disp(' ');
                disp('[盤面]');
                for i=0:2
                    line='';
                    for j=0:2
                        if screen(i+j*3+2)==1
                            line=[line 'O '];
                        elseif screen(i+j*3+2)==2
                            line=[line 'X '];                    
                        else
                            line=[line '_ '];
                        end 
                    end
                    disp(line);
                end
            end
        catch e
            str='';
        end

        % 勝敗判定
        if (screen(2)==screen(3))&&(screen(3)==screen(4))
            win=screen(2);
        elseif (screen(5)==screen(6))&&(screen(6)==screen(7))
            win=screen(5);
        elseif (screen(8)==screen(9))&&(screen(9)==screen(10))
            win=screen(8);
        elseif (screen(2)==screen(5))&&(screen(5)==screen(8))
            win=screen(2);
        elseif (screen(3)==screen(6))&&(screen(6)==screen(9))
            win=screen(3);
        elseif (screen(4)==screen(7))&&(screen(7)==screen(10))
            win=screen(4);
        elseif (screen(2)==screen(6))&&(screen(6)==screen(10))
            win=screen(2);
        elseif (screen(4)==screen(6))&&(screen(6)==screen(8))
            win=screen(4);
        else
            win=0;
        end
        if win>0
            if win==marubatsu
                disp('あなたの勝ちです。');
                str='';
            else
                disp('あなたの負けです。');
                str='';
            end
        else
            if sum(screen==[0 0 0 0 0 0 0 0 0 0])==0
                tmp=input('引き分けです。');
                str='';                
            end
        end
        
        if strcmp(str,'')==0
            if ((marubatsu==1)&&(mod(screen(1),2)==0)) || ((marubatsu==2)&&(mod(screen(1),2)==1))
                % 自分の順番
                disp('あなたの番です。');
                disp('1 4 7 ');
                disp('2 5 8 ');
                disp('3 6 9 ');
                if marubatsu==1
                    disp('Oをつける場所を、');
                else
                    disp('Xをつける場所を、');
                end
                indata = input('1～9から選んで下さい：');
                indata = indata + 1;

                if screen(indata)==0
                    tmp=screen;
                    tmp(1)=tmp(1)+1;                
                    tmp(indata)=marubatsu;

                    % 盤面データをサーバーに設定する。
                    param = num2str(tmp);                
                    param = replace(param,'  ','_');
                    req = matlab.net.http.RequestMessage;
                    uri = matlab.net.URI(['http://' serverip '/index.htm?command=ScreenSet&parameter=' param]);
                    try
                        rsp = send(req,uri); % サーバーに送信して応答を受け取る。
                    catch e
                        str='';
                    end
                end
            else
                % 相手の順番
                if sum(screen==screen_before)<10
                    disp('相手の番です。');
                end 
                pause(2);
            end
            screen_before=screen;
        end
    end
    
    % ゲーム終了をサーバーに教える。
    req = matlab.net.http.RequestMessage;
    uri = matlab.net.URI(['http://' serverip '/index.htm?command=GameEnd&parameter=']);
    try
        rsp = send(req,uri); % サーバーに送信して応答を受け取る。
        disp('ゲーム終了');
    catch e
        disp('ゲーム終了');
    end
end
