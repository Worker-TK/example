function result = client_game_save_screen(indata)
    assignin('base','screen',indata);
    result = indata;
end
