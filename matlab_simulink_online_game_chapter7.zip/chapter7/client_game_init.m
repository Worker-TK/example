function result = client_game_init()
    % localhostにはサーバーのパブリックIPを設定
    serverip = 'localhost:8080';
    assignin('base','serverip',serverip);    
    
    matching = 0;
    assignin('base','matching',matching);
    marubatsu = 0;
    assignin('base','marubatsu',marubatsu);
    cycle = 0;
    assignin('base','cycle',cycle);
    screen = zeros(3,3);
    assignin('base','screen',screen);
    judge = 0;
    assignin('base','judge',judge);
    set_param('matlab_simulink_online_game/マッチング処理/マッチングなし時の処理/マッチング実行ボタン操作','Value', '0');
    set_param('matlab_simulink_online_game/ゲーム制御処理/マッチング完了時のみ実行する処理/操作できる時の処理/ユーザー操作','Value', '0');
    set_param('matlab_simulink_online_game/ゲーム終了処理/ゲーム終了ボタン操作','Value', '0');
end
