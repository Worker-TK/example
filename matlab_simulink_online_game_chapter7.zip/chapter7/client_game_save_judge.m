function result = client_game_save_judge(indata)
    assignin('base','judge',indata);
    result = indata;
end
