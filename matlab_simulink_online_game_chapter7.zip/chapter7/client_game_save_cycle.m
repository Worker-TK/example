function result = client_game_save_cycle(indata)
    assignin('base','cycle',indata);
    result = indata;
end
