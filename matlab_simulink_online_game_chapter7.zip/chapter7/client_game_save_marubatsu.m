function result = client_game_save_marubatsu(indata)
    assignin('base','marubatsu',indata);
    result = indata;
end
