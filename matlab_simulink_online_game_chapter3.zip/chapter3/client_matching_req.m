function result = client_matching_req(indata)
    if indata == 0
        result = zeros(1,10); % マッチング実行ボタンを押すまで何もしない。
    else
        % サーバーにマッチング要求する。
        req = matlab.net.http.RequestMessage;
        uri = matlab.net.URI('http://localhost:8080/index.htm?command=MatchingReq&parameter=');
        try
            rsp = send(req,uri); % サーバーに送信して応答を受け取る。
            dat = transpose(rsp.Body.Data); % 行と列を転置する。
            result = [double(dat) zeros(1,10-size(dat,2))]; % 戻り値の長さを10固定にする。
            disp(['REQ:' native2unicode(result)]); % 戻り値を文字に変換して表示する。(デバッグ用)
        catch e
            result = zeros(1,10);
            disp('REQ:TIMEOUT'); % タイムアウトしたことを表示する。(デバッグ用)
        end
    end
end