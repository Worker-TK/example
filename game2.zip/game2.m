% [タイトル]
%  テトリスっぽいけど少し違うゲーム
% [ルール]
%  ・青バーのカウントダウンが0になるまで以下の操作ができます。
%    上下：ブロック左右回転
%    左右：ブロック左右移動
%    Enter：リスタート
%    Esc：ゲーム中断
%  ・青バーのカウントダウンが0になるとブロックが落下します。
%  ・積み上がったブロックが赤線を超えるとゲーム終了です。
%  ・ゲーム終了すると赤線より下のブロックの密閉率を表示します。
%    100%に違いほど良い結果ということになります。

% ゲーム本体
function game2()
    global screen_h;
    global screen_w;
    global parts_s;
    global count_max;
    global key;

    % パラメータを定義する
    screen_h=26;    
    screen_w=14;
    parts_s=50;
    count_max=35;
    
    % 部品を作る
    [base parts]=make_parts();

    % 画面を作る
    fig=make_screen();

    % 繰り返す
    rng('shuffle');
    while true
        new=1;
        
        % ゲーム中
        while true
            % 落下させるブロックを作る
            if new==1
                parts_now=parts(:,:,randi(7));
                count=count_max;
                key=0;
                x=6;
                y=1;
                new=0;
            end

            if count==0
                % 落下を判定する
                y_tmp=y+1;
                judge=base(y_tmp:y_tmp+3,x:x+3).*parts_now;
                if sum(sum(judge))>0
                    new=1;
                else
                    y=y+1;
                end
            else
                % 操作を判定する
                if key==1
                    parts_now=fliplr(parts_now');
                elseif key==2
                    x=x+1;
                    if x>(screen_w-3)
                        x=screen_w-3;
                    end
                elseif key==3
                    parts_now=fliplr(parts_now)';
                elseif key==4
                    x=x-1;
                    if x<1
                        x=1;
                    end
                elseif key==7
                    close(fig);
                    return;
                end
            end
            key=0;

            % 表示させる内容を作る
            if new==0
                base_tmp=base;
                base_tmp(y:y+3,x:x+3)=base_tmp(y:y+3,x:x+3)+parts_now;
            else
                base(y:y+3,x:x+3)=base(y:y+3,x:x+3)+parts_now;
                base_tmp=base;
            end

            % 画面を表示する
            show_screen(base_tmp,count);
            if count>0
                count=count-1;
            end

            % ゲームオーバーを判定する
            if sum(sum(base(1:4,1:screen_w)))>0
                result=uint8(sum(sum(base(5:screen_h-2,3:screen_w-2)))/2);
                text(10,100,[num2str(result) '%'],...
                    'FontSize',50,'Color','#00FF00','FontWeight','bold');
                game_start=0;
                break;
            end            

            % ウェイトを入れる(値を小さくすると早くなる)
            pause(0.02);
        end
        
        % リスタート待ち
        while true
            if key==5
                base=init();
                break;
            elseif key==7
                close(fig);
                return;
            end
            pause(0.1);
        end
    end
end

% 初期化する
function [base]=init()
    global screen_h;
    global screen_w;

    base=zeros(screen_h,screen_w);
    for i=5:screen_h
        base(i,1,:)=1;
        base(i,2,:)=1;
        base(i,end,:)=1;
        base(i,end-1,:)=1;
    end
    for j=3:screen_w-2
        base(end,j,:)=1;
        base(end-1,j,:)=1;
    end
end

% 部品を作る
function [base parts]=make_parts()
    global screen_h;
    global screen_w;
    global parts_s;
    global parts0;
    global parts1;
    global screen_tmp;

    % 初期化する
    base=init();

    parts0=uint8(zeros(parts_s,parts_s,3));
    parts1=parts0;
    parts1(3:parts_s-2,3:parts_s-2,:)=uint8(ones(parts_s-4,parts_s-4,3))*255;
    parts1(7:parts_s-6,7:parts_s-6,:)=uint8(ones(parts_s-12,parts_s-12,3))*240;
    screen_tmp=uint8(zeros(screen_h*parts_s+20,screen_w*parts_s,3));
    
    parts(:,:,1)=[0 0 1 0; 0 0 1 0; 0 0 1 0; 0 0 1 0];
    parts(:,:,2)=[0 0 0 0; 0 1 1 0; 0 1 1 0; 0 0 0 0];
    parts(:,:,3)=[0 0 0 0; 0 1 1 1; 0 0 1 0; 0 0 0 0];
    parts(:,:,4)=[0 0 0 0; 1 1 1 0; 0 0 1 0; 0 0 0 0];
    parts(:,:,5)=[0 0 0 0; 1 1 1 0; 1 0 0 0; 0 0 0 0];
    parts(:,:,6)=[0 0 0 0; 0 1 1 0; 0 0 1 1; 0 0 0 0];
    parts(:,:,7)=[0 0 0 0; 0 0 1 1; 0 1 1 0; 0 0 0 0];
end

% 画面を作る
function fig=make_screen()
    fig = figure;
    fig.Name = 'GAME';
    fig.NumberTitle = 'off';
    fig.MenuBar = 'none';
    fig.ToolBar = 'none';

    fig.KeyPressFcn = @key_press_callback;    
    function key_press_callback(src,data)
        global key;

        if strcmp(data.Key,'uparrow')
            key=1;
        elseif strcmp(data.Key,'rightarrow')
            key=2;
        elseif strcmp(data.Key,'downarrow')
            key=3;
        elseif strcmp(data.Key,'leftarrow')
            key=4;
        elseif strcmp(data.Key,'return')
            key=5;
        elseif strcmp(data.Key,'space')
            key=6;
        elseif strcmp(data.Key,'escape')
            key=7;
        end
    end
end

% 画面を表示する
function show_screen(base,count)
    global screen_h;
    global screen_w;
    global parts_s;
    global count_max;
    global parts0;
    global parts1;
    global screen_tmp;
    
    screen=screen_tmp;
    for i=1:screen_h
        for j=1:screen_w
            if base(i,j)==1
                screen((i-1)*parts_s+21:(i-1)*parts_s+parts_s+20,...
                       (j-1)*parts_s+1:(j-1)*parts_s+parts_s,:)=parts1;
            else
                screen((i-1)*parts_s+21:(i-1)*parts_s+parts_s+20,...
                       (j-1)*parts_s+1:(j-1)*parts_s+parts_s,:)=parts0;
            end
        end
    end
    screen_count=uint8(zeros(20,screen_w*parts_s,3));
    screen_count(1:20,1:count*(screen_w*parts_s/count_max),3)...
          =uint8(ones(20,count*(screen_w*parts_s/count_max)))*255;
    screen(1:20,1:screen_w*parts_s,:)=screen_count;
    screen(4*parts_s+19:4*parts_s+22,1:screen_w*parts_s,1)...
          =uint8(ones(4,screen_w*parts_s))*255;
    imshow(screen,'Border','tight');
end
