function matlab_mobile_controller
    first=0;
    max=30;
    limit=400/tan(max*pi/180);
    req=matlab.net.http.RequestMessage;
    serverip='localhost:8080'; % localhostにはサーバーのパブリックIPを設定
    m=mobiledev;
    m.OrientationSensorEnabled=1;
    m.Logging=1;
    while 1
        log=m.Orientation;
        if length(log)<3
            continue;
        end
        if first==0
            log0=log(1);
            first=1;
        end
        x0=log(1);
        x0=x0-log0;
        if x0<-180
            x0=x0+360;
        elseif x0>180
            x0=x0-360;
        end
        if x0>max
            x0=max;
        elseif x0<-max
            x0=-max;
        end
        x=int32(tan(x0*pi/180)*limit);
        y0=log(2);
        if y0>max
            y0=max;
        elseif y0<-max
            y0=-max;
        end
        y=int32(-tan(y0*pi/180)*limit);
        x_s=x+401;
        if x_s>800
            x_s=800;
        end
        y_s=y+401;
        if y_s>800
            y_s=800;
        end
        disp(['x=' num2str(x_s) ',y=' num2str(y_s)]); % デバッグ用
        uri = matlab.net.URI(['http://' serverip '/index.htm?x=' num2str(x_s) '&y=' num2str(y_s)]);
        try
            rsp=send(req,uri);
        catch e
            disp('ERROR');
        end
        pause(0.01);
    end
end
