function client_matlab_mobile
    first=0;
    serverip='localhost:8080'; % localhostにはサーバーのパブリックIPを設定
    req = matlab.net.http.RequestMessage;
    uri = matlab.net.URI(['http://' serverip '/index.htm']);
    fig = figure;
    fig.Name = 'MATLAB Mobile Controller';
    fig.NumberTitle = 'off';
    fig.MenuBar = 'none';
    fig.ToolBar = 'none';
    pic=imread('game_ken_seiken.png');
    screen0=ones(900,900,3)*255;
    screen0=cast(screen0,'uint8');
    while 1
        try
            rsp = send(req,uri); % サーバーに送信して応答を受け取る。
            dat = transpose(rsp.Body.Data); % 行と列を転置する。
            str = native2unicode([double(dat) zeros(1,10-size(dat,2))]); % 10固定の文字に変換する。
            str = replace(str,'_',' '); % アンダーバーをスペースに置換する。
            result = str2num(str); % 戻り値は数値配列とする。
%            disp(str); % 戻り値を文字で表示する。(デバッグ用)
            x=result(1);
            y=801-result(2);
            if first==0
                x_p=int32(ones(1,10))*x;
                y_p=int32(ones(1,10))*y;
                first=1;
            else
                x_p=[x_p x];
                x_p=x_p(2:11);
                y_p=[y_p y];
                y_p=y_p(2:11);
            end
            screen=screen0;
            screen(y:y+99,x:x+99,1:3)=pic(1:100,1:100,1:3);
            imshow(screen,'Border','tight');
            hold on
            plot(x_p,y_p,'k');
            drawnow;
            pause(0.01);
        catch e
            disp('ERROR');
        end
    end
end