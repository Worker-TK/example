# サーバーを開始する。
Write-Host "Online game server start."
$listener = New-Object system.net.HttpListener
$listener.Prefixes.Add('http://127.0.0.1:8080/') # 127.0.0.1:8080にはサーバーのプライベートIPを設定
$listener.Start()

$x = "400"
$y = "400"

while($true)
{
	# クライアントからコマンドとパラメーターを受け取る。
	$context = $listener.GetContext()
	$request = $context.Request
	$input = $request.RawUrl.Replace("/index.htm?", "")

	# コマンドに対する応答を作る。
	$output = ""
	$array = $input.Split("&")
	if($array.Length -eq 2){
		$x = $array[0].Replace("x=", "")
		$y = $array[1].Replace("y=", "")
		$output = "OK"
#		Write-Host $x $y
	}else{
		$output = $x + "_" + $y
	}

	# クライアントへ応答を返す。
	$buffer = [System.Text.Encoding]::UTF8.GetBytes($output)
 	$response = $context.Response
	$response.ContentLength64 = $buffer.Length
	$output = $response.OutputStream
	$output.Write($buffer,0,$buffer.Length)
	$output.Close()
}
