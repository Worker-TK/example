function chapter11_picture_rgb_script
    global pic;
    global pic_r;
    global pic_g;
    global pic_b;
    global sz;
    global fig;

    [file,path] = uigetfile({'*.jpg;*.jpeg','JPEG';'*.*','All Files (*.*)'},'写真を選んでください');
    if isequal(file,0)
        return;
    else
        pic=imread(fullfile(path,file),'jpg');
    end

    sz=size(pic);
    fig = figure;
    fig.Name = 'Picture RGB';
    fig.NumberTitle = 'off';
    fig.MenuBar = 'none';
    fig.ToolBar = 'none';
    fig.Resize = 'off';
    pos=fig.Position;
    pos(1)=10;
    pos(1)=10;
    pos(3)=sz(2)*3;
    pos(4)=sz(1)+100;
    fig.Position=pos;
    
    pic_r=zeros(sz(1),sz(2),sz(3));
    pic_r(:,:,1)=pic(:,:,1);
    pic_r(:,:,2)=pic(:,:,1);
    pic_r(:,:,3)=pic(:,:,1);

    pic_b=zeros(sz(1),sz(2),sz(3));
    pic_b(:,:,1)=pic(:,:,2);
    pic_b(:,:,2)=pic(:,:,2);
    pic_b(:,:,3)=pic(:,:,2);

    pic_g=zeros(sz(1),sz(2),sz(3));
    pic_g(:,:,1)=pic(:,:,3);
    pic_g(:,:,2)=pic(:,:,3);
    pic_g(:,:,3)=pic(:,:,3);
    
    picture_random;
end

function picture_random
    global pic;
    global pic_r;
    global pic_g;
    global pic_b;
    global sz;
    global fig;
    global left;
    global center;
    global right;
   
    rng('shuffle');
    rnd=randi(6);
    switch rnd
        case 1
            left   = pic_r;
            center = pic_b;
            right  = pic_g;
        case 2
            left   = pic_r;
            center = pic_g;
            right  = pic_b;            
        case 3
            left   = pic_b;
            center = pic_r;
            right  = pic_g;
        case 4
            left   = pic_b;
            center = pic_g;
            right  = pic_r;            
        case 5
            left   = pic_g;
            center = pic_r;
            right  = pic_b;
        case 6
            left   = pic_g;
            center = pic_b;            
            right  = pic_r;
    end
        
    screen=zeros(sz(1)+100,sz(2)*3,sz(3));
    screen=cast(screen,'uint8');
    screen(101:100+sz(1),1+sz(2)*1:sz(2)*2,:)=pic(:,:,:);
    
    imshow(screen,'Border','tight','InitialMagnification','fit');    
    uicontrol(fig,'Style','pushbutton','String','RGB分割','Position',[(sz(2)*3-100)/2,sz(1)+100-40,100,30],'Callback',{@button_split_callback});
end

function button_split_callback(source,eventdata) 
    global sz;
    global left;
    global center;
    global right;

    screen_tmp=zeros(sz(1)+100,sz(2)*3,sz(3));
    screen_tmp=cast(screen_tmp,'uint8');
    
    max=50;
    for i=0:max
        screen=screen_tmp;
        screen(101:100+sz(1),1+sz(2)*1-int32(sz(2)*i/max):sz(2)*2-int32(sz(2)*i/max),:) =  left(:,:,:);
        screen(101:100+sz(1),1+sz(2)*1                   :sz(2)*2                   ,:) = center(:,:,:);
        screen(101:100+sz(1),1+sz(2)*1+int32(sz(2)*i/max):sz(2)*2+int32(sz(2)*i/max),:) = right(:,:,:);
        imshow(screen,'Border','tight','InitialMagnification','fit');
        pause(0.001); 
    end        

    picture_show;
end

function picture_show
    global sz;
    global fig;
    global left;
    global center;
    global right;
    
    screen_tmp=zeros(sz(1)+100,sz(2)*3,sz(3));
    screen_tmp=cast(screen_tmp,'uint8');
    screen=screen_tmp;
    screen(101:100+sz(1),1+sz(2)*0:sz(2)*1,:) =  left(:,:,:);
    screen(101:100+sz(1),1+sz(2)*1:sz(2)*2,:) = center(:,:,:);
    screen(101:100+sz(1),1+sz(2)*2:sz(2)*3,:) = right(:,:,:);
    imshow(screen,'Border','tight','InitialMagnification','fit');
    
    uicontrol(fig,'Style','pushbutton','String','RGB結合','Position',[(sz(2)*3-100)/2,sz(1)+100-40,100,30],'Callback',{@button_join_callback});
    uicontrol(fig,'Style','pushbutton','String','赤','Position',[(sz(2)-50*3)/2+50*0+sz(2)*0,sz(1)+100-90,50,30],'Callback',{@button_left_r_callback});
    uicontrol(fig,'Style','pushbutton','String','緑','Position',[(sz(2)-50*3)/2+50*1+sz(2)*0,sz(1)+100-90,50,30],'Callback',{@button_left_g_callback});
    uicontrol(fig,'Style','pushbutton','String','青','Position',[(sz(2)-50*3)/2+50*2+sz(2)*0,sz(1)+100-90,50,30],'Callback',{@button_left_b_callback});
    uicontrol(fig,'Style','pushbutton','String','赤','Position',[(sz(2)-50*3)/2+50*0+sz(2)*1,sz(1)+100-90,50,30],'Callback',{@button_center_r_callback});
    uicontrol(fig,'Style','pushbutton','String','緑','Position',[(sz(2)-50*3)/2+50*1+sz(2)*1,sz(1)+100-90,50,30],'Callback',{@button_center_g_callback});
    uicontrol(fig,'Style','pushbutton','String','青','Position',[(sz(2)-50*3)/2+50*2+sz(2)*1,sz(1)+100-90,50,30],'Callback',{@button_center_b_callback});
    uicontrol(fig,'Style','pushbutton','String','赤','Position',[(sz(2)-50*3)/2+50*0+sz(2)*2,sz(1)+100-90,50,30],'Callback',{@button_right_r_callback});
    uicontrol(fig,'Style','pushbutton','String','緑','Position',[(sz(2)-50*3)/2+50*1+sz(2)*2,sz(1)+100-90,50,30],'Callback',{@button_right_g_callback});
    uicontrol(fig,'Style','pushbutton','String','青','Position',[(sz(2)-50*3)/2+50*2+sz(2)*2,sz(1)+100-90,50,30],'Callback',{@button_right_b_callback});
end

function button_left_r_callback(source,eventdata) 
    global sz;
    global left;
    
    s1=sum(left(:,:,1),'all');
    s2=sum(left(:,:,2),'all');
    if s1>0
        left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
        left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    elseif s2>0
        left(:,:,1)=left(:,:,2);
        left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
        left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    else
        left(:,:,1)=left(:,:,3);
        left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
        left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    end
    picture_show;
end

function button_left_g_callback(source,eventdata) 
    global sz;
    global left;
    
    s1=sum(left(:,:,1),'all');
    s2=sum(left(:,:,2),'all');
    if s1>0
        left(:,:,2)=left(:,:,1);
        left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    elseif s2>0
        left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    else
        left(:,:,2)=left(:,:,3);
        left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    end
    picture_show;
end

function button_left_b_callback(source,eventdata) 
    global sz;
    global left;
    
    s1=sum(left(:,:,1),'all');
    s2=sum(left(:,:,2),'all');
    if s1>0
        left(:,:,3)=left(:,:,1);
        left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
    elseif s2>0
        left(:,:,3)=left(:,:,2);
        left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
    else
        left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
    end
    picture_show;
end

function button_center_r_callback(source,eventdata) 
    global sz;
    global center;
    
    s1=sum(center(:,:,1),'all');
    s2=sum(center(:,:,2),'all');
    if s1>0
        center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
        center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    elseif s2>0
        center(:,:,1)=center(:,:,2);
        center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
        center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    else
        center(:,:,1)=center(:,:,3);
        center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
        center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    end
    picture_show;
end

function button_center_g_callback(source,eventdata) 
    global sz;
    global center;
    
    s1=sum(center(:,:,1),'all');
    s2=sum(center(:,:,2),'all');
    if s1>0
        center(:,:,2)=center(:,:,1);
        center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    elseif s2>0
        center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    else
        center(:,:,2)=center(:,:,3);
        center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    end
    picture_show;
end

function button_center_b_callback(source,eventdata) 
    global sz;
    global center;
    
    s1=sum(center(:,:,1),'all');
    s2=sum(center(:,:,2),'all');
    if s1>0
        center(:,:,3)=center(:,:,1);
        center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
    elseif s2>0
        center(:,:,3)=center(:,:,2);
        center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
    else
        center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
    end
    picture_show;
end

function button_right_r_callback(source,eventdata) 
    global sz;
    global right;
    
    s1=sum(right(:,:,1),'all');
    s2=sum(right(:,:,2),'all');
    if s1>0
        right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
        right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    elseif s2>0
        right(:,:,1)=right(:,:,2);
        right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
        right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    else
        right(:,:,1)=right(:,:,3);
        right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
        right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    end
    picture_show;
end

function button_right_g_callback(source,eventdata) 
    global sz;
    global right;
    
    s1=sum(right(:,:,1),'all');
    s2=sum(right(:,:,2),'all');
    if s1>0
        right(:,:,2)=right(:,:,1);
        right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    elseif s2>0
        right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    else
        right(:,:,2)=right(:,:,3);
        right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
    end
    picture_show;
end

function button_right_b_callback(source,eventdata) 
    global sz;
    global right;
    
    s1=sum(right(:,:,1),'all');
    s2=sum(right(:,:,2),'all');
    if s1>0
        right(:,:,3)=right(:,:,1);
        right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
    elseif s2>0
        right(:,:,3)=right(:,:,2);
        right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
    else
        right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
        right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
    end
    picture_show;
end

function button_join_callback(source,eventdata) 
    global sz;
    global fig;
    global left;
    global center;
    global right;

    screen_tmp=zeros(sz(1)+100,sz(2)*3,sz(3));
    screen_tmp=cast(screen_tmp,'uint8');
    
    max=50;
    for i=0:max
        screen=screen_tmp;
        screen(101:100+sz(1),1+sz(2)*1-int32(sz(2)*(max-i)/max):sz(2)*2-int32(sz(2)*(max-i)/max),:) =  left(:,:,:);
        screen(101:100+sz(1),1+sz(2)*1                         :sz(2)*2                         ,:) = center(:,:,:);
        screen(101:100+sz(1),1+sz(2)*1+int32(sz(2)*(max-i)/max):sz(2)*2+int32(sz(2)*(max-i)/max),:) = right(:,:,:);
        imshow(screen,'Border','tight','InitialMagnification','fit');
        pause(0.001); 
    end        

    pic=left+center+right;
    screen=screen_tmp;
    screen(101:100+sz(1),1+sz(2)*1:sz(2)*2,:)=pic(:,:,:);
    imshow(screen,'Border','tight','InitialMagnification','fit');
    
    uicontrol(fig,'Style','pushbutton','String','リトライ','Position',[(sz(2)*3-100)/2,sz(1)+100-40,100,30],'Callback',{@button_reset_callback});
end

function button_reset_callback(source,eventdata) 
    picture_random;
end

