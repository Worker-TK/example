classdef chapter12_picture_rgb_screen < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure             matlab.ui.Figure
        Button_split         matlab.ui.control.Button
        Image                matlab.ui.control.Image
        Button_join          matlab.ui.control.Button
        Button_retry         matlab.ui.control.Button
        Button_left_red      matlab.ui.control.Button
        Button_left_green    matlab.ui.control.Button
        Button_left_blue     matlab.ui.control.Button
        Button_center_red    matlab.ui.control.Button
        Button_center_green  matlab.ui.control.Button
        Button_center_blue   matlab.ui.control.Button
        Button_right_red     matlab.ui.control.Button
        Button_right_green   matlab.ui.control.Button
        Button_right_blue    matlab.ui.control.Button
        Button_select        matlab.ui.control.Button
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function init(app)
            global screen_tmp;
            screen_tmp=zeros(300,1200,3);
            screen_tmp=cast(screen_tmp,'uint8');
            app.Image.ImageSource = screen_tmp;
        end

        % Button pushed function: Button_select
        function select_picture(app, event)
            global pic;
            global sz;
            global pic_r;
            global pic_g;
            global pic_b;
            global screen;
            global screen_tmp;
            
            app.Button_split.Enable = 'off';            
            app.Button_join.Enable = 'off';            
            app.Button_retry.Enable = 'off';
            app.Button_left_red.Enable = 'off';            
            app.Button_left_green.Enable = 'off';            
            app.Button_left_blue.Enable = 'off';            
            app.Button_center_red.Enable = 'off';            
            app.Button_center_green.Enable = 'off';            
            app.Button_center_blue.Enable = 'off';            
            app.Button_right_red.Enable = 'off';            
            app.Button_right_green.Enable = 'off';            
            app.Button_right_blue.Enable = 'off';
            
            [file,path] = uigetfile({'*.jpg;*.jpeg','JPEG';'*.*','All Files (*.*)'},'写真を選んでください');
            if isequal(file,0)
                % 何もしない
            else
                pic=imread(fullfile(path,file),'jpg');
                sz=size(pic);
                screen_tmp=zeros(sz(1),sz(2)*3,sz(3));
                screen_tmp=cast(screen_tmp,'uint8');
                screen=screen_tmp;
                screen(1:sz(1),1+sz(2):sz(2)*2,:)=pic(:,:,:);  
                app.Image.ImageSource = screen;
                app.Button_split.Enable = 'on';
                
                pic_r=zeros(sz(1),sz(2),sz(3));
                pic_r(:,:,1)=pic(:,:,1);
                pic_r(:,:,2)=pic(:,:,1);
                pic_r(:,:,3)=pic(:,:,1);
                pic_b=zeros(sz(1),sz(2),sz(3));
                pic_b(:,:,1)=pic(:,:,2);
                pic_b(:,:,2)=pic(:,:,2);
                pic_b(:,:,3)=pic(:,:,2);
                pic_g=zeros(sz(1),sz(2),sz(3));
                pic_g(:,:,1)=pic(:,:,3);
                pic_g(:,:,2)=pic(:,:,3);
                pic_g(:,:,3)=pic(:,:,3);
            end
        end

        % Button pushed function: Button_split
        function split_picture(app, event)
            global sz;
            global pic_r;
            global pic_g;
            global pic_b;
            global left;
            global center;
            global right;
            global screen;
            global screen_tmp;
            
            rng('shuffle');
            rnd=randi(6);
            switch rnd
                case 1
                    left   = pic_r;
                    center = pic_b;
                    right  = pic_g;
                case 2
                    left   = pic_r;
                    center = pic_g;
                    right  = pic_b;
                case 3
                    left   = pic_b;
                    center = pic_r;
                    right  = pic_g;
                case 4
                    left   = pic_b;
                    center = pic_g;
                    right  = pic_r;
                case 5
                    left   = pic_g;
                    center = pic_r;
                    right  = pic_b;
                case 6
                    left   = pic_g;
                    center = pic_b;
                    right  = pic_r;
            end            

            max=20;
            for i=0:max
                screen=screen_tmp;
                screen(1:sz(1),1+sz(2)*1-int32(sz(2)*i/max):sz(2)*2-int32(sz(2)*i/max),:) =   left(:,:,:);
                screen(1:sz(1),1+sz(2)*1                   :sz(2)*2                   ,:) = center(:,:,:);
                screen(1:sz(1),1+sz(2)*1+int32(sz(2)*i/max):sz(2)*2+int32(sz(2)*i/max),:) =  right(:,:,:);
                app.Image.ImageSource = screen;
                pause(0.001); 
            end        
            
            app.Button_split.Enable = 'off';            
            app.Button_join.Enable = 'on';            
            app.Button_left_red.Enable = 'on';            
            app.Button_left_green.Enable = 'on';            
            app.Button_left_blue.Enable = 'on';            
            app.Button_center_red.Enable = 'on';            
            app.Button_center_green.Enable = 'on';            
            app.Button_center_blue.Enable = 'on';            
            app.Button_right_red.Enable = 'on';            
            app.Button_right_green.Enable = 'on';            
            app.Button_right_blue.Enable = 'on';  
        end

        % Button pushed function: Button_join
        function join_picture(app, event)
            global sz;
            global left;
            global center;
            global right;
            global screen;
            global screen_tmp;

            max=20;
            for i=0:max
                screen=screen_tmp;
                screen(1:sz(1),1+sz(2)*1-int32(sz(2)*(max-i)/max):sz(2)*2-int32(sz(2)*(max-i)/max),:) =   left(:,:,:);
                screen(1:sz(1),1+sz(2)*1                         :sz(2)*2                         ,:) = center(:,:,:);
                screen(1:sz(1),1+sz(2)*1+int32(sz(2)*(max-i)/max):sz(2)*2+int32(sz(2)*(max-i)/max),:) =  right(:,:,:);
                app.Image.ImageSource = screen;
                pause(0.001); 
            end        
            pic_tmp=left+center+right;
            screen=screen_tmp;
            screen(1:sz(1),1+sz(2)*1:sz(2)*2,:)=pic_tmp(:,:,:);
            app.Image.ImageSource = screen;
            
            app.Button_join.Enable = 'off';            
            app.Button_retry.Enable = 'on';                          
            app.Button_left_red.Enable = 'off';            
            app.Button_left_green.Enable = 'off';            
            app.Button_left_blue.Enable = 'off';            
            app.Button_center_red.Enable = 'off';            
            app.Button_center_green.Enable = 'off';            
            app.Button_center_blue.Enable = 'off';            
            app.Button_right_red.Enable = 'off';            
            app.Button_right_green.Enable = 'off';            
            app.Button_right_blue.Enable = 'off';  
        end

        % Button pushed function: Button_retry
        function retry_picture(app, event)
            global pic;
            global sz;
            global screen;
            global screen_tmp;

            screen=screen_tmp;
            screen(1:sz(1),1+sz(2)*1:sz(2)*2,:)=pic(:,:,:);
            app.Image.ImageSource = screen;
            
            app.Button_split.Enable = 'on';            
            app.Button_retry.Enable = 'off';                          
        end

        % Button pushed function: Button_left_red
        function left_red(app, event)
            global sz;
            global left;
            global center;
            global right;
            global screen;
            global screen_tmp;
    
            s1=sum(left(:,:,1),'all');
            s2=sum(left(:,:,2),'all');
            if s1>0
                left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
                left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            elseif s2>0
                left(:,:,1)=left(:,:,2);
                left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
                left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            else
                left(:,:,1)=left(:,:,3);
                left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
                left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            end

            screen=screen_tmp;
            screen(1:sz(1),1+sz(2)*0:sz(2)*1,:) =  left(:,:,:);
            screen(1:sz(1),1+sz(2)*1:sz(2)*2,:) = center(:,:,:);
            screen(1:sz(1),1+sz(2)*2:sz(2)*3,:) = right(:,:,:);
            app.Image.ImageSource = screen;            
        end

        % Button pushed function: Button_left_green
        function left_green(app, event)
            global sz;
            global left;
            global center;
            global right;
            global screen;
            global screen_tmp;

            s1=sum(left(:,:,1),'all');
            s2=sum(left(:,:,2),'all');
            if s1>0
                left(:,:,2)=left(:,:,1);
                left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            elseif s2>0
                left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            else
                left(:,:,2)=left(:,:,3);
                left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                left(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            end
            
            screen=screen_tmp;
            screen(1:sz(1),1+sz(2)*0:sz(2)*1,:) =  left(:,:,:);
            screen(1:sz(1),1+sz(2)*1:sz(2)*2,:) = center(:,:,:);
            screen(1:sz(1),1+sz(2)*2:sz(2)*3,:) = right(:,:,:);
            app.Image.ImageSource = screen;
        end

        % Button pushed function: Button_left_blue
        function left_blue(app, event)
            global sz;
            global left;
            global center;
            global right;
            global screen;
            global screen_tmp;

            s1=sum(left(:,:,1),'all');
            s2=sum(left(:,:,2),'all');
            if s1>0
                left(:,:,3)=left(:,:,1);
                left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
            elseif s2>0
                left(:,:,3)=left(:,:,2);
                left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
            else
                left(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                left(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
            end
            
            screen=screen_tmp;
            screen(1:sz(1),1+sz(2)*0:sz(2)*1,:) =  left(:,:,:);
            screen(1:sz(1),1+sz(2)*1:sz(2)*2,:) = center(:,:,:);
            screen(1:sz(1),1+sz(2)*2:sz(2)*3,:) = right(:,:,:);
            app.Image.ImageSource = screen;            
        end

        % Button pushed function: Button_center_red
        function center_red(app, event)
            global sz;
            global left;
            global center;
            global right;
            global screen;
            global screen_tmp;

            s1=sum(center(:,:,1),'all');
            s2=sum(center(:,:,2),'all');
            if s1>0
                center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
                center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            elseif s2>0
                center(:,:,1)=center(:,:,2);
                center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
                center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            else
                center(:,:,1)=center(:,:,3);
                center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
                center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            end
            
            screen=screen_tmp;
            screen(1:sz(1),1+sz(2)*0:sz(2)*1,:) =  left(:,:,:);
            screen(1:sz(1),1+sz(2)*1:sz(2)*2,:) = center(:,:,:);
            screen(1:sz(1),1+sz(2)*2:sz(2)*3,:) = right(:,:,:);
            app.Image.ImageSource = screen;            
        end

        % Button pushed function: Button_center_green
        function center_green(app, event)
            global sz;
            global left;
            global center;
            global right;
            global screen;
            global screen_tmp;
            
            s1=sum(center(:,:,1),'all');
            s2=sum(center(:,:,2),'all');
            if s1>0
                center(:,:,2)=center(:,:,1);
                center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            elseif s2>0
                center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            else
                center(:,:,2)=center(:,:,3);
                center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                center(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            end

            screen=screen_tmp;
            screen(1:sz(1),1+sz(2)*0:sz(2)*1,:) =  left(:,:,:);
            screen(1:sz(1),1+sz(2)*1:sz(2)*2,:) = center(:,:,:);
            screen(1:sz(1),1+sz(2)*2:sz(2)*3,:) = right(:,:,:);
            app.Image.ImageSource = screen;            
        end

        % Button pushed function: Button_center_blue
        function center_blue(app, event)
            global sz;
            global left;
            global center;
            global right;
            global screen;
            global screen_tmp;

            s1=sum(center(:,:,1),'all');
            s2=sum(center(:,:,2),'all');
            if s1>0
                center(:,:,3)=center(:,:,1);
                center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
            elseif s2>0
                center(:,:,3)=center(:,:,2);
                center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
            else
                center(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                center(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
            end
            
            screen=screen_tmp;
            screen(1:sz(1),1+sz(2)*0:sz(2)*1,:) =  left(:,:,:);
            screen(1:sz(1),1+sz(2)*1:sz(2)*2,:) = center(:,:,:);
            screen(1:sz(1),1+sz(2)*2:sz(2)*3,:) = right(:,:,:);
            app.Image.ImageSource = screen;            
        end

        % Button pushed function: Button_right_green
        function right_green(app, event)
            global sz;
            global left;
            global center;
            global right;
            global screen;
            global screen_tmp;

            s1=sum(right(:,:,1),'all');
            s2=sum(right(:,:,2),'all');
            if s1>0
                right(:,:,2)=right(:,:,1);
                right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            elseif s2>0
                right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            else
                right(:,:,2)=right(:,:,3);
                right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            end
            
            screen=screen_tmp;
            screen(1:sz(1),1+sz(2)*0:sz(2)*1,:) =  left(:,:,:);
            screen(1:sz(1),1+sz(2)*1:sz(2)*2,:) = center(:,:,:);
            screen(1:sz(1),1+sz(2)*2:sz(2)*3,:) = right(:,:,:);
            app.Image.ImageSource = screen;            
        end

        % Button pushed function: Button_right_blue
        function right_blue(app, event)
            global sz;
            global left;
            global center;
            global right;
            global screen;
            global screen_tmp;

            s1=sum(right(:,:,1),'all');
            s2=sum(right(:,:,2),'all');
            if s1>0
                right(:,:,3)=right(:,:,1);
                right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
            elseif s2>0
                right(:,:,3)=right(:,:,2);
                right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
            else
                right(:,:,1)=cast(zeros(sz(1),sz(2)),'uint8');
                right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
            end
            
            screen=screen_tmp;
            screen(1:sz(1),1+sz(2)*0:sz(2)*1,:) =  left(:,:,:);
            screen(1:sz(1),1+sz(2)*1:sz(2)*2,:) = center(:,:,:);
            screen(1:sz(1),1+sz(2)*2:sz(2)*3,:) = right(:,:,:);
            app.Image.ImageSource = screen;            
        end

        % Button pushed function: Button_right_red
        function right_red(app, event)
            global sz;
            global left;
            global center;
            global right;
            global screen;
            global screen_tmp;

            s1=sum(right(:,:,1),'all');
            s2=sum(right(:,:,2),'all');
            if s1>0
                right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
                right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            elseif s2>0
                right(:,:,1)=right(:,:,2);
                right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
                right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            else
                right(:,:,1)=right(:,:,3);
                right(:,:,2)=cast(zeros(sz(1),sz(2)),'uint8');
                right(:,:,3)=cast(zeros(sz(1),sz(2)),'uint8');
            end
            
            screen=screen_tmp;
            screen(1:sz(1),1+sz(2)*0:sz(2)*1,:) =  left(:,:,:);
            screen(1:sz(1),1+sz(2)*1:sz(2)*2,:) = center(:,:,:);
            screen(1:sz(1),1+sz(2)*2:sz(2)*3,:) = right(:,:,:);
            app.Image.ImageSource = screen;                        
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.AutoResizeChildren = 'off';
            app.UIFigure.Position = [100 100 1200 400];
            app.UIFigure.Name = 'MATLAB App';
            app.UIFigure.Resize = 'off';

            % Create Button_split
            app.Button_split = uibutton(app.UIFigure, 'push');
            app.Button_split.ButtonPushedFcn = createCallbackFcn(app, @split_picture, true);
            app.Button_split.Enable = 'off';
            app.Button_split.Position = [500 355 100 27];
            app.Button_split.Text = 'RGB分割';

            % Create Image
            app.Image = uiimage(app.UIFigure);
            app.Image.Position = [1 1 1200 300];

            % Create Button_join
            app.Button_join = uibutton(app.UIFigure, 'push');
            app.Button_join.ButtonPushedFcn = createCallbackFcn(app, @join_picture, true);
            app.Button_join.Enable = 'off';
            app.Button_join.Position = [600 355 100 27];
            app.Button_join.Text = 'RGB結合';

            % Create Button_retry
            app.Button_retry = uibutton(app.UIFigure, 'push');
            app.Button_retry.ButtonPushedFcn = createCallbackFcn(app, @retry_picture, true);
            app.Button_retry.Enable = 'off';
            app.Button_retry.Position = [700 355 100 27];
            app.Button_retry.Text = 'リトライ';

            % Create Button_left_red
            app.Button_left_red = uibutton(app.UIFigure, 'push');
            app.Button_left_red.ButtonPushedFcn = createCallbackFcn(app, @left_red, true);
            app.Button_left_red.Enable = 'off';
            app.Button_left_red.Position = [50 315 100 27];
            app.Button_left_red.Text = '赤';

            % Create Button_left_green
            app.Button_left_green = uibutton(app.UIFigure, 'push');
            app.Button_left_green.ButtonPushedFcn = createCallbackFcn(app, @left_green, true);
            app.Button_left_green.Enable = 'off';
            app.Button_left_green.Position = [150 315 100 27];
            app.Button_left_green.Text = '緑';

            % Create Button_left_blue
            app.Button_left_blue = uibutton(app.UIFigure, 'push');
            app.Button_left_blue.ButtonPushedFcn = createCallbackFcn(app, @left_blue, true);
            app.Button_left_blue.Enable = 'off';
            app.Button_left_blue.Position = [250 315 100 27];
            app.Button_left_blue.Text = '青';

            % Create Button_center_red
            app.Button_center_red = uibutton(app.UIFigure, 'push');
            app.Button_center_red.ButtonPushedFcn = createCallbackFcn(app, @center_red, true);
            app.Button_center_red.Enable = 'off';
            app.Button_center_red.Position = [450 315 100 27];
            app.Button_center_red.Text = '赤';

            % Create Button_center_green
            app.Button_center_green = uibutton(app.UIFigure, 'push');
            app.Button_center_green.ButtonPushedFcn = createCallbackFcn(app, @center_green, true);
            app.Button_center_green.Enable = 'off';
            app.Button_center_green.Position = [550 315 100 27];
            app.Button_center_green.Text = '緑';

            % Create Button_center_blue
            app.Button_center_blue = uibutton(app.UIFigure, 'push');
            app.Button_center_blue.ButtonPushedFcn = createCallbackFcn(app, @center_blue, true);
            app.Button_center_blue.Enable = 'off';
            app.Button_center_blue.Position = [650 315 100 27];
            app.Button_center_blue.Text = '青';

            % Create Button_right_red
            app.Button_right_red = uibutton(app.UIFigure, 'push');
            app.Button_right_red.ButtonPushedFcn = createCallbackFcn(app, @right_red, true);
            app.Button_right_red.Enable = 'off';
            app.Button_right_red.Position = [850 314 100 27];
            app.Button_right_red.Text = '赤';

            % Create Button_right_green
            app.Button_right_green = uibutton(app.UIFigure, 'push');
            app.Button_right_green.ButtonPushedFcn = createCallbackFcn(app, @right_green, true);
            app.Button_right_green.Enable = 'off';
            app.Button_right_green.Position = [950 315 100 27];
            app.Button_right_green.Text = '緑';

            % Create Button_right_blue
            app.Button_right_blue = uibutton(app.UIFigure, 'push');
            app.Button_right_blue.ButtonPushedFcn = createCallbackFcn(app, @right_blue, true);
            app.Button_right_blue.Enable = 'off';
            app.Button_right_blue.Position = [1050 315 100 27];
            app.Button_right_blue.Text = '青';

            % Create Button_select
            app.Button_select = uibutton(app.UIFigure, 'push');
            app.Button_select.ButtonPushedFcn = createCallbackFcn(app, @select_picture, true);
            app.Button_select.Position = [400 355 100 27];
            app.Button_select.Text = '画像選択';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = chapter12_picture_rgb_screen

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @init)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end