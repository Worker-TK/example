#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <stdio.h>

#define COMMAND_RECV "/tmp/pipe.command_recv"
#define COMMAND_SEND "/tmp/pipe.command_send"

void main(int argc, char** argv)
{
    char command[1024];
    int fd_recv, fd_send;
    fd_recv = open(COMMAND_SEND, O_RDWR);
    fd_send = open(COMMAND_RECV, O_RDWR);

    if(argc<1)
    {
        printf("[コマンド受付アプリ]コマンドライン引数でコマンドを入力してください。\n");
    }
    else
    {
        memset(command,0,1024);
        for (int i = 1 ; i < argc ; i++ )
        {
            if(i == (argc - 1))
            {
                sprintf(command + strlen(command), "%s", argv[i]);
            }
            else
            {
                sprintf(command + strlen(command), "%s ", argv[i]);
            }
        }
        write(fd_send,command,strlen(command)+1);
        printf("[コマンド受付アプリ]入力されたコマンド：\"%s\"\n",command);/* 正式処理では不要 */

        char str_recv[1024];
        read(fd_recv,str_recv,1024);
        printf("[コマンド受付アプリ]受信したコマンド実行結果\n");/* 正式処理では不要 */
        printf("%s",str_recv);
    }

    close(fd_recv);
    close(fd_send);

    return;
}
