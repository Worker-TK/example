#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <stdio.h>

/* 処理追加:名前付きパイプを定義する */
#define COMMAND_RECV "./pipe.command_recv"
#define COMMAND_SEND "./pipe.command_send"

void main(void)
{
    /* 処理追加:初期処理で名前付きパイプを作ってオープンする */
    mkfifo(COMMAND_RECV, S_IRWXU);
    mkfifo(COMMAND_SEND, S_IRWXU);
    int fd_recv;
    int fd_send;
    fd_recv = open(COMMAND_RECV, O_RDWR);
    fd_send = open(COMMAND_SEND, O_RDWR);

    char str_recv[1024];
    while(1)
    {
        /* 処理変更:コマンド入力を、標準入力から名前付きパイプにする */
#if 0
        fgets(str_recv,255,stdin);
#else
        read(fd_recv,str_recv,1024);
#endif

        /* ダミーの処理実行(正式処理では不要) */
        printf("[メインアプリ]入力されたコマンド:\"%s\"\n",str_recv);
        printf("[メインアプリ]処理開始\n");
        usleep(1000*2000);
        printf("[メインアプリ]処理1実行\n");
        printf("[メインアプリ]処理2実行\n");
        printf("[メインアプリ]処理終了\n");

        /* 処理変更:コマンド出力を標準出力から名前付きパイプにする※コマンド以外の標準出力は変える必要はない */
#if 0
        printf("[メインアプリ]処理1結果=%s","ABC");
        printf("[メインアプリ]処理2結果=%s","DEF");
#else
        char str_send[1024];
        memset(str_send,0,1024);
        sprintf(str_send + strlen(str_send),"処理1結果=%s\n","ABC");
        sprintf(str_send + strlen(str_send),"処理2結果=%s\n","DEF");
        write(fd_send,str_send,strlen(str_send)+1);
#endif
    }

    /* 処理追加:終了処理で名前付きパイプをクローズする */
    close(fd_recv);
    close(fd_send);

    return;
}
