# サーバーを開始する。
Write-Host "Online game server start."
$listener = New-Object system.net.HttpListener
$listener.Prefixes.Add('http://127.0.0.1:8080/') # 127.0.0.1にはサーバーのプライベートIPを設定
$listener.Start()

$matching = "INIT" # マッチング状況を初期化する。
$data = "0_0_0_0_0_0_0_0_0_0" # 盤面データを初期化する。
$gameend = 0 # ゲーム終了人数を初期化する。

while($true)
{
	# クライアントからコマンドとパラメーターを受け取る。
	$context = $listener.GetContext()
	$request = $context.Request
	$input = $request.RawUrl.Replace("/index.htm?", "")

	# コマンドに対する応答を作る。
	$array = $input.Split("&")
	$command = $array[0].Replace("command=", "")
	$parameter = $array[1].Replace("parameter=", "")
	if($command.Equals("MatchingReq")){        # [コマンド：マッチング要求]
		if($matching.Equals("INIT")){          # ・マッチング状況がINIT(マッチングなし)の場合、
			$matching = "WAIT"                 # 　WAIT(マッチング待ち)を応答とする。
			$gameend = 1
			$output = $matching
		}elseif($matching.Equals("WAIT")){     # ・マッチング状況がWAIT(マッチング待ち)の場合、
			$matching = "COMPLETE"             # 　COMPLETE(マッチング完了)を応答とする。
			$gameend = 0
			$output = $matching
		}elseif($matching.Equals("COMPLETE")){ # ・マッチング状況がCOMPLETE(マッチング完了)の場合、
			$output = "FAILURE"                # 　FAILURE(別の人がマッチングして空きがない)を応答とする。
		}
	}elseif($command.Equals("MatchingGet")){   # [コマンド：マッチング状況取得]
		$output = $matching                    # ・マッチング状況を応答とする。
	}elseif($command.Equals("ScreenSet")){     # [コマンド：盤面データ設定]
		$data = $parameter                     # ・パラメーターを盤面データとして保持する。
		$output = $data                        # ・盤面データを応答とする。
	}elseif($command.Equals("ScreenGet")){     # [コマンド：盤面データ取得]
		$output = $data                        # ・盤面データを応答とする。
	}elseif($command.Equals("GameEnd")){       # [コマンド：ゲーム終了]
		$gameend = $gameend + 1                # ・ゲーム終了人数を＋１する。
		if($gameend -eq 2){                    # ・ゲーム終了人数が2の場合、
			$matching = "INIT"                 # 　－マッチング状況を初期化する。
			$data = "0_0_0_0_0_0_0_0_0_0"      # 　－盤面データを初期化する。
			$gameend = 0                       # 　－ゲーム終了人数を初期化する。
		}
		$output = "OK"                         # ・OKを応答とする。
	}

	# クライアントへ応答を返す。
	$buffer = [System.Text.Encoding]::UTF8.GetBytes($output)
 	$response = $context.Response
	$response.ContentLength64 = $buffer.Length
	$output = $response.OutputStream
	$output.Write($buffer,0,$buffer.Length)
	$output.Close()
}
