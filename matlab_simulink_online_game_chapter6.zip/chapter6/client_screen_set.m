function result = client_screen_set(indata)
    % サーバーのパブリックIPを取得
    serverip=evalin('base','serverip');

    % 盤面データをサーバーに設定する。
    param = num2str(transpose(indata));
    param = replace(param,'  ','_');
    req = matlab.net.http.RequestMessage;
    uri = matlab.net.URI(['http://' serverip '/index.htm?command=ScreenSet&parameter=' param]);
    try
        rsp = send(req,uri); % サーバーに送信して応答を受け取る。
        dat = transpose(rsp.Body.Data); % 行と列を転置する。
        str = native2unicode([double(dat) zeros(1,19-size(dat,2))]); % 19固定の文字に変換する。
        str = replace(str,'_',' '); % アンダーバーをスペースに置換する。
        result = str2num(str); % 戻り値は数値配列とする。
%        disp(['SCR SET:' str]); % 戻り値を文字で表示する。(デバッグ用)
        assignin('base','screen',result);
    catch e
        result = zeros(1,10);
        disp('SCR SET:TIMEOUT'); % タイムアウトしたことを表示する。(デバッグ用)
    end
end
