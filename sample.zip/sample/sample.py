import os
import subprocess
import shutil
import zipfile
import pysvn
import git
import openpyxl

class SvnClient:
    def __init__(self, user, passwd):
        self.client = pysvn.Client()
        self.user = user
        self.passwd = passwd
        self.client.callback_get_login = self.get_login

    def get_login(self, realm, username, may_save):
        return True, self.user,self.passwd, False

    def info2(self, src_url_or_path, branch, filename):
        return self.client.info2(src_url_or_path + "/" + branch + "/" + filename)

    def export(self, src_url_or_path, branch, filename, dest_path, revision):
        ret = False
        try:
            if revision == "head":
                self.client.export(src_url_or_path + "/" + branch + "/" + filename, dest_path, revision=pysvn.Revision(pysvn.opt_revision_kind.head), recurse=True)
            else:
                self.client.export(src_url_or_path + "/" + branch + "/" + filename, dest_path, revision=pysvn.Revision(pysvn.opt_revision_kind.number, int(revision)), recurse=True)
            ret = True
        except Exception as e:
            print(e)
        return ret

    def __del__(self):
        self.client = None
        self.user = None
        self.passwd = None
        self.client.callback_get_login = None

class GitClient:
    def __init__(self, user, passwd):
#        self.client = git.Repo.init()
        self.user = user
        self.passwd = passwd

    def clone(self, src_url_or_path, branch, filename, dest_path, revision):
        ret = False
        try:
            self.client = git.Repo.clone_from(src_url_or_path, dest_path, branch=branch, no_checkout=True)
            ret = True
        except Exception as e:
            print(e)
        return ret

    def checkout(self, src_url_or_path, branch, filename, dest_path, revision):
        ret = False
        try:
            self.client.git.checkout(revision, filename)
            ret = True
        except Exception as e:
            print(e)
        return ret

if __name__ == '__main__':

    try:
        shutil.rmtree("zip")
    except Exception as e:
        print(e)

    try:
        os.mkdir("zip")
    except Exception as e:
        print(e)

    src_url_or_path = "https://localhost/svn/repos"
    branch = "trunk"
#    filename = "test.txt"
    filename = "test"
    dest_path = "./svn"
    user = "svnuser"
    passwd = "svnuser"
    revision = "head"
    output = "./zip/test_svn.zip"
    output = output.replace(".zip", "")

    try:
        if os.name == "nt":
            subprocess.run("rmdir /q /s .\svn", shell=True)
        else:
            subprocess.run("rm -rf ./svn", shell=True)
    except Exception as e:
        print(e)

    try:
        os.mkdir(dest_path)
    except Exception as e:
        print(e)

    client = SvnClient(user, passwd)

    is_dir = False
    entry_list = client.info2(src_url_or_path, branch, filename)
    for entry_path, entry_info in entry_list:
        if entry_info.URL == src_url_or_path + "/" + branch + "/" + filename:
            if entry_info.kind == pysvn.node_kind.dir:
                is_dir = True
                break

    if is_dir == True:
        ret = client.export(src_url_or_path, branch, filename, dest_path + "/" + filename, revision)
    else:
        ret = client.export(src_url_or_path, branch, filename, dest_path, revision)

    shutil.make_archive(output, format="zip", root_dir=dest_path, base_dir=filename)

    src_url_or_path = "https://github.com/Worker-TK/example.git"
    branch = "main"
    filename = "game.zip"
#    filename = "test"
    dest_path = "./git"
    user = "gituser"
    passwd = "gituser"
#    revision = "43be273bb5cba8c8ac365e5b1135521fcf8ab247"
    revision = "HEAD"
    output = "./zip/test_git.zip"
    output = output.replace(".zip", "")

    try:
        if os.name == "nt":
            subprocess.run("rmdir /q /s .\git", shell=True)
        else:
            subprocess.run("rm -rf ./git", shell=True)
    except Exception as e:
        print(e)

    try:
        os.mkdir(dest_path)
    except Exception as e:
        print(e)

    client = GitClient(user, passwd)
    ret = client.clone(src_url_or_path, branch, filename, dest_path, revision)
    ret = client.checkout(src_url_or_path, branch, filename, dest_path, revision)

    shutil.make_archive(output, format="zip", root_dir=dest_path, base_dir=filename)

    try:
        if os.name == "nt":
            subprocess.run("rmdir /q /s .\git\.git", shell=True)
        else:
            subprocess.run("rm -rf ./git/.git", shell=True)
    except Exception as e:
        print(e)

    wb = openpyxl.load_workbook("./xlsx/test.xlsx")
    ws_list = wb.worksheets
    ws = wb["Sheet1"]
    for i in range(1, 4):
        for j in range(1, 9):
            cell = ws.cell(i, j)
            val = cell.value
            print(val)
        print("-----")
