function matlab_mobile_game1
    % ゲームの説明
    disp('スマホを筆に見立てて手に持ち、');
    disp('一筆描きで絵を書いてください。');
    pause(1);
    disp('腕をまっすぐ伸ばして、');
    disp('レーザーポインタで遠くに描くような');
    disp('イメージをすると上手く描けます。');
    pause(1);
    disp('制限時間は約10秒です。');
    disp('３、２、１でスタートします。');
    pause(1);
    disp('３');
    pause(1);
    disp('２');
    pause(1);
    disp('１');
    pause(1);
    disp('スタート！');
    
    % センサーデータを取得
    m = mobiledev;
    m.Logging = 1;
    for i=1:10
        % pause(10)がエラーになるので、
        % 1秒×10回でウェイトを入れる。    
        pause(1);
    end
    m.Logging = 0;
    [log, t] = orientlog(m);
    
    % 結果発表
    disp('終了です。');
    disp('描いた絵を友達に見せて、');
    disp('何を描いたか当ててもらってください。');

    % センサーデータをもとに絵を描画
    x0=log(:,1);
    x0=x0-x0(1);
    x0(x0<-180)=x0(x0<-180)+360;
    x0(x0>180)=x0(x0>180)-360;
    x0(x0>60)=60;
    x0(x0<-60)=-60;
    x=tan(x0*pi/180);    
    y0=log(:,2);
    y0(y0>60)=60;
    y0(y0<-60)=-60;
    y=-tan(y0*pi/180);
    plot(x,y);
    xlim([-1.8 1.8]);
    ylim([-1.8 1.8]);
    
    % 終了処理
    discardlogs(m);
    clear m;
end
