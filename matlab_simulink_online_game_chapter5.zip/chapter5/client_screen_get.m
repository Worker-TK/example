function result = client_screen_get(indata)
    % 盤面データをサーバーから取得する。
    req = matlab.net.http.RequestMessage;
    uri = matlab.net.URI('http://localhost:8080/index.htm?command=ScreenGet&parameter=');
    try
        rsp = send(req,uri); % サーバーに送信して応答を受け取る。
        dat = transpose(rsp.Body.Data); % 行と列を転置する。
        str = native2unicode([double(dat) zeros(1,19-size(dat,2))]); % 19固定の文字に変換する。
        str = replace(str,'_',' '); % アンダーバーをスペースに置換する。
        result = str2num(str); % 戻り値は数値配列とする。
%        disp(['SCR GET:' str]); % 戻り値を文字で表示する。(デバッグ用)
        assignin('base','screen',result);
    catch e
        result = zeros(1,10);
        disp('SCR GET:TIMEOUT'); % タイムアウトしたことを表示する。(デバッグ用)
    end
end