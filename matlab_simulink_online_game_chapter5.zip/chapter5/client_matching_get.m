function result = client_matching_get(indata)
    % サーバーからマッチング状況を取得する。
    req = matlab.net.http.RequestMessage;
    uri = matlab.net.URI('http://localhost:8080/index.htm?command=MatchingGet&parameter=');
    try
        rsp = send(req,uri); % サーバーに送信して応答を受け取る。
        dat = transpose(rsp.Body.Data); % 行と列を転置する。
        result = [double(dat) zeros(1,10-size(dat,2))]; % 戻り値の長さを10固定にする。
        disp(['MAT GET:' native2unicode(result)]); % 戻り値を文字に変換して表示する。(デバッグ用)
    catch e
        result = zeros(1,10);
        disp('MAT GET:TIMEOUT'); % タイムアウトしたことを表示する。(デバッグ用)
    end
end
